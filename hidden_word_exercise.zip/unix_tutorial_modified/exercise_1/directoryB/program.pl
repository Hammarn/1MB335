#!/usr/bin/perl

use strict;
use warnings;

print "\nThe third character is 'M'\.\n\n";
